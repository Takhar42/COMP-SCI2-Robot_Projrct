
#include "circleC.h"
//#include "line.h"  //add your line code
#include <fstream>
using namespace std;

class Parse
{
  private:
    //tserial *robo;
    PointXY Current;
    PointXY Target;
    PointXY Center;
    ifstream GCODEin;                   //GCode input file
	char     GCODE = ' ';               //Store Current G command
	double  CurrentX = 9, CurrentY = 9; //Store currentbines.
	double   X=0.0,Y=0.0,I=0.0,J=0.0,Z=0.0;//Store new target position
	unsigned index;     //Index to individual command ln.
	circle TestCircle;  //Instance of circle class ,Pass robot tserial to TestCircle by reference
  //line   TestLine;    //Make instance of your line code pass robot tseral by refernce
	bool QuilOutFlag = false; //Assume pen on white board
	string CommandLine;  //Store individual command lines.
    string Direction;
    char textch;
  public:
    Parse(string nameFile){GCODEin.open(nameFile);}  //Use new to create tserial, then Add connect
                                                     //Open the tserail and make instance
    ~Parse(){GCODEin.close();} //Close tseral
    void parseLine();
    void getGODE();
    void getX();
    void getY();
    void getI();
    void getJ();
    void getZ();

};