#include "Parse.h"
#include <iostream>
#include <iomanip>
using namespace std;

void Parse::parseLine()
{
	unsigned LineLength;     //Hold lengtgh of current line.
	char CharsIn[80] = {0};  //holds char array
 	CommandLine = "";        //blank out the string
	if(!GCODEin.eof() && GCODE != '8')    //Read if not end of file
	{
       GCODEin.getline(CharsIn, 80);
       for(int i = 0; i < strlen(CharsIn); i++)
          CommandLine += CharsIn[i];
    }
	else
	  return;
	LineLength = CommandLine.length();

	//Collect G XYIJ values in each line
	for(index = 0; index < LineLength; index++)
	{
  	   //cout << CommandLine[index];
  	   switch (CommandLine[index])
  	   {
		   case 'G' : getGODE();
		              break;
		   case 'X' : getX();
		              break;
		   case 'Y' : getY();
		              break;
		   case 'I' : getI();
		              break;
		   case 'J' : getJ();
		              break;
		   case 'Z' : getZ();
		              break;
	   }
    }


    //Display current G XYIJ values for next move Demo only
	cout << "G0" << GCODE << " X" << setw(7) << X << " Y" <<  setw(7) << Y
	                      << " I" << setw(7) << I << " J" <<  setw(7) << J ;
	//call line or circle given current and new XYIJ Values
	switch(GCODE)
	{
		case '0': //call line class and populate the Gcommand in the class
                  //IF Z != 1 move waist out 10 clicks set flag('QuilOutFlag'on board)
                  //  move out 10 clicks and set QuilOutFlag to true
                  //If Z == 0 check flag('QuilOutFlag'are we out) and move in 10
                  //  move  in 10 clicks and set 'QuilOutFlag' to false


		case '1': //call line class and populate the Gcommand in the class
		          //call line method
		          CurrentX = X;
		          CurrentY = Y;
		          break;
				  //Add call to your line and any setup
		case '2':
		case '3': //call circle CW  and populate the Gcommand in the class
		          //Account for arc center position
                  //add feature to allow Center (i,j)
		          Current = {CurrentX, CurrentY};
		          cout << "Current X: "<< X << "  " << "Current Y: " << Y << endl;
		          Target  = {X, Y};
		          Center  = {I, J};
		          Direction = (GCODE == '2')? "CW" : "CCW";
		          TestCircle.DoitC(Current,Target,Direction,0.5, Center); //Add Center point param add tserail pointer
		          CurrentX = Target.X + Center.X; //Update current point
		          CurrentY = Target.Y + Center.Y;
		          break;
	}

}

void Parse::getI()
{
	string Temp = "";
	while(isdigit(CommandLine[++index])|| CommandLine[index] == '.'||CommandLine[index] == '-')
       Temp.append(1, CommandLine[index]); //Append characters to a temp string
	I = atof(Temp.c_str());
	--index;
}

void Parse::getJ()
{
	string Temp = "";
	while(isdigit(CommandLine[++index])|| CommandLine[index] == '.'||CommandLine[index] == '-')
       Temp.append(1, CommandLine[index]);
	J = atof(Temp.c_str());
	--index;
}

void Parse::getY()
{
	string Temp = "";
	while(isdigit(CommandLine[++index])|| CommandLine[index] == '.'||CommandLine[index] == '-')
       Temp.append(1, CommandLine[index]);
	Y = atof(Temp.c_str());
	--index;
}

void Parse::getX()
{
	string Temp = "";
	while(isdigit(CommandLine[++index])|| CommandLine[index] == '.'||CommandLine[index] == '-')
       Temp.append(1, CommandLine[index]);
	X = atof(Temp.c_str());
	--index;
}

void Parse::getZ()
{
	string Temp = "";
	while(isdigit(CommandLine[++index])|| CommandLine[index] == '.'||CommandLine[index] == '-')
       Temp.append(1, CommandLine[index]);
	Z = atof(Temp.c_str());
	--index;
}

void Parse::getGODE()
{
	GCODE = CommandLine[2]; //Grab the actual charcter for the G0,1,2,or 3
	index = 2;
}

